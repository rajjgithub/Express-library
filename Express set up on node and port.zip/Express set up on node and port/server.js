const express = require('express');
const app = express()

const port = 5000

app.get('/',(req, res) => {
    res.send("Hello my fellow developer")
})

app.listen(port, () => 
    console.log(`The app is listening on port  ${port}`))


